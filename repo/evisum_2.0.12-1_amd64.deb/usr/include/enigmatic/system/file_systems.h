#ifndef __FILESYSTEMS_H__
#define __FILESYSTEMS_H__

#include <Eina.h>
#include <limits.h>
#include "enigmatic_visibility.h"

#if defined(__linux__)
# include <linux/limits.h>
#endif

typedef struct {
   uint64_t total;
   uint64_t used;
   uint64_t read;
   uint64_t write;
} _Usage;

typedef struct _File_System {
   char         path[PATH_MAX];
   char         mount[PATH_MAX];
   char         type_name[64];
   unsigned int type;
   _Usage       usage;

   int          unique_id;
} File_System;

ENIGMATIC_API Eina_List *
file_systems_find(void);

ENIGMATIC_API void
file_system_info_free(File_System *fs);

ENIGMATIC_API Eina_Bool
file_system_in_use(const char *name);

#endif
