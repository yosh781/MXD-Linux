#ifndef _ECORE_AUDIO_OUT_SYSTEM_EO_H_
#define _ECORE_AUDIO_OUT_SYSTEM_EO_H_

#ifndef _ECORE_AUDIO_OUT_SYSTEM_EO_CLASS_TYPE
#define _ECORE_AUDIO_OUT_SYSTEM_EO_CLASS_TYPE

typedef Eo Ecore_Audio_Out_System;

#endif

#ifndef _ECORE_AUDIO_OUT_SYSTEM_EO_TYPES
#define _ECORE_AUDIO_OUT_SYSTEM_EO_TYPES


#endif
#ifdef EFL_BETA_API_SUPPORT
/**
 * @brief Portable audio output using WASAPI on Windows and PulseAudio
 * elsewhere, with PipeWire as a fallback when PulseAudio is unavailable.
 *
 * Successful backend selection is shared by all system outputs and cached for
 * the lifetime of the process. On non-Windows platforms, the first output
 * probes PulseAudio first, then PipeWire if PulseAudio cannot connect. Probes
 * use native connections without constructing audio output objects, and each
 * backend caches successful availability probes. If neither server is
 * available, detection retries once per second while outputs are waiting.
 * Later outputs construct the selected backend directly, even if that backend
 * subsequently fails. ECORE_AUDIO_BACKEND can select pipewire or pulseaudio
 * (pulse is an alias) explicitly, disabling fallback. Unset, empty or auto
 * uses detection. Unknown or unavailable explicit backends fail construction.
 * The variable is read once and ignored on Windows.
 *
 * Unsuccessful automatic detection keeps outputs and queued requests waiting
 * for a server to become available. If a retry cannot be scheduled or no
 * backend is compiled in, context,fail is emitted. Construction fails if
 * initial detection cannot be scheduled or an already selected backend cannot
 * be created. Inputs are attached to the owned backend, so
 * Ecore.Audio.In.output returns that backend. Input lists and playback
 * capabilities follow the backend. While detection or connection is pending,
 * volume, pause, input and VIO requests are retained and replayed in order
 * when the backend is ready. Synchronous getters report the queued state
 * during this interval. Queued inputs are retained until replay, failure or
 * output destruction. Source and format remain unsupported. Windows uses
 * WASAPI immediately.
 *
 * @ingroup Ecore_Audio_Out_System
 */
#define ECORE_AUDIO_OUT_SYSTEM_CLASS ecore_audio_out_system_class_get()

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK const Efl_Class *ecore_audio_out_system_class_get(void) EINA_CONST;

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK extern const Efl_Event_Description _ECORE_AUDIO_OUT_SYSTEM_EVENT_CONTEXT_READY;

/** Called when the backend is ready for playback.
 *
 * @ingroup Ecore_Audio_Out_System
 */
#define ECORE_AUDIO_OUT_SYSTEM_EVENT_CONTEXT_READY (&(_ECORE_AUDIO_OUT_SYSTEM_EVENT_CONTEXT_READY))

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK extern const Efl_Event_Description _ECORE_AUDIO_OUT_SYSTEM_EVENT_CONTEXT_FAIL;

/** Called when the backend context fails.
 *
 * @ingroup Ecore_Audio_Out_System
 */
#define ECORE_AUDIO_OUT_SYSTEM_EVENT_CONTEXT_FAIL (&(_ECORE_AUDIO_OUT_SYSTEM_EVENT_CONTEXT_FAIL))

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK extern const Efl_Event_Description _ECORE_AUDIO_OUT_SYSTEM_EVENT_STOP;

/** Forwarded when the backend requests a stop (WASAPI only).
 *
 * @ingroup Ecore_Audio_Out_System
 */
#define ECORE_AUDIO_OUT_SYSTEM_EVENT_STOP (&(_ECORE_AUDIO_OUT_SYSTEM_EVENT_STOP))
#endif /* EFL_BETA_API_SUPPORT */

#endif
