#ifndef _ECORE_AUDIO_OUT_PIPEWIRE_EO_H_
#define _ECORE_AUDIO_OUT_PIPEWIRE_EO_H_

#ifndef _ECORE_AUDIO_OUT_PIPEWIRE_EO_CLASS_TYPE
#define _ECORE_AUDIO_OUT_PIPEWIRE_EO_CLASS_TYPE

typedef Eo Ecore_Audio_Out_Pipewire;

#endif

#ifndef _ECORE_AUDIO_OUT_PIPEWIRE_EO_TYPES
#define _ECORE_AUDIO_OUT_PIPEWIRE_EO_TYPES


#endif
#ifdef EFL_BETA_API_SUPPORT
/**
 * @brief Ecore audio output for PipeWire.
 *
 * Inputs use individual floating-point playback streams. Connection and stream
 * failures are reported through context,fail. Callbacks and input reads run on
 * the Ecore main loop.
 *
 * @ingroup Ecore_Audio_Out_Pipewire
 */
#define ECORE_AUDIO_OUT_PIPEWIRE_CLASS ecore_audio_out_pipewire_class_get()

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK const Efl_Class *ecore_audio_out_pipewire_class_get(void) EINA_CONST;

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK extern const Efl_Event_Description _ECORE_AUDIO_OUT_PIPEWIRE_EVENT_CONTEXT_READY;

/** Called when the output is ready for playback.
 *
 * @ingroup Ecore_Audio_Out_Pipewire
 */
#define ECORE_AUDIO_OUT_PIPEWIRE_EVENT_CONTEXT_READY (&(_ECORE_AUDIO_OUT_PIPEWIRE_EVENT_CONTEXT_READY))

ECORE_AUDIO_API ECORE_AUDIO_API_WEAK extern const Efl_Event_Description _ECORE_AUDIO_OUT_PIPEWIRE_EVENT_CONTEXT_FAIL;

/** Called when the context or a stream fails.
 *
 * @ingroup Ecore_Audio_Out_Pipewire
 */
#define ECORE_AUDIO_OUT_PIPEWIRE_EVENT_CONTEXT_FAIL (&(_ECORE_AUDIO_OUT_PIPEWIRE_EVENT_CONTEXT_FAIL))
#endif /* EFL_BETA_API_SUPPORT */

#endif
