#!/usr/bin/sh

case "$1" in
    start)
	sh -c "$HOME/.dinit.d/scripts/rc.local" && ls -1 $HOME/.dinit.d/scripts/rc-local/*.start  |  while read script; do sh -c $script;  done;
	;;
	
    stop)
    ls -1 $HOME/.dinit.d/scripts/rc-local/*.stop  |  while read script; do sh -c $script;  done;
    ;;

    *)
    exit 1
    ;;
esac
