#!/bin/sh

export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u)/bus"

dinitctl setenv DBUS_SESSION_BUS_ADDRESS || :

exec /usr/bin/dbus-daemon --session --address="$DBUS_SESSION_BUS_ADDRESS" "$@"
