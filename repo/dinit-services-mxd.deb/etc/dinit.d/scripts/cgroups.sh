#!/bin/sh
#2026 MXD Linux https://github.com/yosh781

[ -r /etc/dinit.d/config/cgroups.conf ] && . /etc/dinit.d/config/cgroups.conf

CGROUP_OPTS=${CGROUP_OPTS:-nodev,noexec,nosuid}
CG_ROOT=${CG_ROOT:-"/sys/fs/cgroup"}
CG_CHILD_NAME=${CG_CHILD_NAME:-"dinit"}
CG_INIT="${CG_ROOT}/${CG_CHILD_NAME}"
CGROUP_MODE=${CGROUP_MODE:-hybrid}
CGROUP_CONTROLLERS=${CGROUP_CONTROLLERS:-"cpu memory pids"}

[ "$CGROUP_CONTROLLERS" = "none" ] && CGROUP_CONTROLLERS=""


cgroup2_find_path() {
    if grep -qw cgroup2 /proc/filesystems; then
        case "${CGROUP_MODE}" in
            hybrid) printf "/sys/fs/cgroup/unified" ;;
            unified) printf "/sys/fs/cgroup" ;;
            *) printf "/sys/fs/cgroup/unified" ;;
        esac
    fi
    return 0
}


cgroup1_base() {
    grep -qw cgroup /proc/filesystems || return 0
    if ! mountpoint -q /sys/fs/cgroup; then
        local opts="${CGROUP_OPTS},mode=755,size=${rc_cgroupsize:-10m}"
        mount -n -t tmpfs -o "${opts}" cgroup_root /sys/fs/cgroup
    fi

    if ! mountpoint -q /sys/fs/cgroup/openrc; then
        local agent
        agent="/etc/dinit.d/scripts/cgroup-release-agent.sh"
        mkdir -p /sys/fs/cgroup/openrc
        mount -n -t cgroup -o "none,${CGROUP_OPTS},name=openrc,release_agent=${agent}" openrc /sys/fs/cgroup/openrc
        printf 1 > /sys/fs/cgroup/openrc/notify_on_release
    fi
    return 0
}


cgroup1_controllers() {
    [ -e /proc/cgroups ] || return 0
    grep -qw cgroup /proc/filesystems || return 0

    while read -r name _ _ enabled _; do
        case "${enabled}" in
            1)
                if mountpoint -q "/sys/fs/cgroup/${name}"; then
                    continue
                fi

                local skip=0
                for x in ${CGROUP_CONTROLLERS}; do
                    [ "${name}" = "blkio" ] && [ "${x}" = "io" ] && skip=1 && break
                    [ "${name}" = "${x}" ] && skip=1 && break
                done
                [ "${skip}" -eq 1 ] && continue

                mkdir -p "/sys/fs/cgroup/${name}"
                mount -n -t cgroup -o "${CGROUP_OPTS},${name}" "${name}" "/sys/fs/cgroup/${name}"
                ;;
        esac
    done < /proc/cgroups
    return 0
}


cgroup2_base() {
    grep -qw cgroup2 /proc/filesystems || return 0
    local base
    base="$(cgroup2_find_path)"
    [ -z "${base}" ] && return 0
    mkdir -p "${base}"
    mount -t cgroup2 none -o "${CGROUP_OPTS},nsdelegate" "${base}" 2> /dev/null ||
        mount -t cgroup2 none -o "${CGROUP_OPTS}" "${base}"
    return 0
}


cgroup2_controllers() {
    grep -qw cgroup2 /proc/filesystems || return 0
    local active cgroup_path x y
    cgroup_path="$(cgroup2_find_path)"
    [ -z "${cgroup_path}" ] && return 0
    [ -e "${cgroup_path}/cgroup.controllers" ] && read -r active < "${cgroup_path}/cgroup.controllers"

    for x in ${CGROUP_CONTROLLERS}; do
        for y in ${active}; do
            if [ "$x" = "$y" ] && [ -e "${cgroup_path}/cgroup.subtree_control" ]; then
                echo "+${x}" > "${cgroup_path}/cgroup.subtree_control" 2>/dev/null || true
            fi
        done
    done
    return 0
}

#for Dinit
create_dinit_cgroup() {
    local cgroup_base
    cgroup_base="$(cgroup2_find_path)"

    if [ -n "${cgroup_base}" ] && [ -d "${cgroup_base}" ]; then

        mkdir -p "${cgroup_base}/${CG_CHILD_NAME}"

        ln -sf "${cgroup_base}/${CG_CHILD_NAME}" "${CG_INIT}" 2>/dev/null || true
    else

        mkdir -p "${CG_INIT}"
    fi


    chmod 755 "${CG_INIT}" 2>/dev/null || true

    return 0
}


cgroups_hybrid() {
    cgroup1_base
    cgroup2_base
    cgroup2_controllers
    cgroup1_controllers
    create_dinit_cgroup
    return 0
}


cgroups_legacy() {
    cgroup1_base
    cgroup1_controllers
    create_dinit_cgroup
    return 0
}


cgroups_unified() {
    cgroup2_base
    cgroup2_controllers
    create_dinit_cgroup
    return 0
}


mount_cgroups() {
    case "${CGROUP_MODE}" in
        hybrid) cgroups_hybrid ;;
        legacy) cgroups_legacy ;;
        unified) cgroups_unified ;;
        *) cgroups_hybrid ;;
    esac
    return 0
}


mount_cgs() {
    if [ -d /sys/fs/cgroup ]; then
        mount_cgroups
        echo "Cgroups setup complete. Dinit cgroup: ${CG_INIT}"
        return 0
    fi
    echo "ERROR: /sys/fs/cgroup not found"
    return 1
}


mount_cgs
