#!/bin/sh

DINIT_SERVICE=local


[ -x /etc/rc.local ] && /etc/rc.local

exit 0
