#!/usr/bin/env python3
"""
Enlightenment Wallpaper Auto-Converter Daemon
"""

import os
import sys
import time
import json
import subprocess
import shutil
import colorsys
from pathlib import Path

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

PALETTE_JSON = Path.home() / ".cache" / "e_wallpaper_palette.json"

class WallpaperConverter:
    def __init__(self, watch_dir, output_dir):
        self.watch_dir = Path(watch_dir).expanduser()
        self.output_dir = Path(output_dir).expanduser()
        self.supported_formats = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}
        self._color_cache = {}  # {path: (mtime, base_rgb)}
        
        self.watch_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"Наблюдение: {self.watch_dir}")
        print(f"Вывод: {self.output_dir}")
    # ========== COLOR SCHEME METHODS ==========
    
    def get_dominant_color(self, image_path):
        if not HAS_PIL:
            return None
        try:
            img_path = Path(image_path)
            mtime = img_path.stat().st_mtime

            # Проверить кэш
            if str(img_path) in self._color_cache:
                cached_mtime, cached_color = self._color_cache[str(img_path)]
                if cached_mtime == mtime:
                    print(f"Кэш: {img_path.name}")
                    return cached_color

            img = Image.open(img_path).convert("RGB")
            img = img.resize((100, 100))
            q = img.quantize(colors=8, method=Image.MEDIANCUT)
            palette = q.getpalette()
            colors = sorted(q.getcolors(), reverse=True)
            idx = colors[0][1]
            r, g, b = palette[idx*3:idx*3+3]

            h, l, s = colorsys.rgb_to_hls(r/255.0, g/255.0, b/255.0)
            if l < 0.15: l = 0.15
            elif l > 0.5: l = 0.5
            if s < 0.05: s = 0.05
            r, g, b = colorsys.hls_to_rgb(h, l, s)

            result = (int(r*255), int(g*255), int(b*255))
            self._color_cache[str(img_path)] = (mtime, result)
            return result
        except Exception as e:
            print(f"Ошибка определения цвета: {e}")
            return None

    def compute_palette(self, base_rgb):

        r, g, b = [x / 255.0 for x in base_rgb]
        h, l, s = colorsys.rgb_to_hls(r, g, b)

        def make(dl, ds=0.0, a=255):

            l2 = max(0.0, min(1.0, l + dl))
            s2 = max(0.0, min(1.0, s + ds))
            r2, g2, b2 = colorsys.hls_to_rgb(h, l2, s2)
            return [int(r2*255), int(g2*255), int(b2*255), a]

        base = [base_rgb[0], base_rgb[1], base_rgb[2], 255]

        palette = {
            # ===== Elementary palette (:name) =====
            "bg":              make(+0.10, 0.0, 225),   # светлее основного
            "bg-alt":          base,          # основной цвет обоев
            "bg-semi":         make(0.0, 0.0, 182),  # панель = bg-alt, полупрозрачная
            "bg-trans":        make(0.0, 0.0, 192),
            "bg-dark":         make(-0.10),   # виджеты рабочего стола
            "bg-dark-alt":     make(-0.18),
            "bg-darkest":      make(-0.25),
            "bg-dark-invisible": make(-0.20, 0.0, 0),
            "bg-dim":          make(+0.15),
            "bg-dimmer":       make(-0.08),
            "bg-dimmest":      make(-0.12),
            "bg-light":        make(+0.15),
            "bg-light-alt":    make(+0.20),
            "bg-medium":       make(+0.08),
            "bg-high":         make(+0.25),
            "bg-higher":       make(+0.30),
            "bg-highest":      make(+0.35),
            "bg-alt-dark":     make(-0.08),
            "bg-alt-light":    make(+0.05),
            "/bg/selected/menu/item":    make(-0.15),
            "/bg/selected/titlebar":    make(+0.20, 0.0, 220),

            # ===== selected (фокус) =====
            "selected":         make(+0.25),   # = toolbar base
            "selected-light":   make(-0.05),
            "selected-medium":  make(-0.12),
            "selected-heavy":   make(-0.25),
            "selected-dim":     make(-0.20),
            "selected-alt":     make(-0.17),
            "selected2":        make(-0.13),
            "selected2-dim":    make(-0.18),
            "selected3":        make(-0.15),
            #"selected4":        make(-0.16),
            "selected4-dim":    make(-0.21),
            "selected5":        make(-0.14),
            "selected5-dim":    make(-0.19),
            "selected6":        make(-0.15),
            "selected6-dim":    make(-0.20),

            # ===== dim =====
            #"dim":              make(-0.05),
            "dim-dark":         make(-0.12),
            "dim-light":        make(+0.05),
            "dim-lighter":      make(+0.25),
            "dim-lightest":     make(+0.15),
        }

        # Работаем ТОЛЬКО через Elementary palette — как paledit
        return {"elementary": palette, "edje": {}}

    def apply_palette_via_eet(self, palette, pal_name="default"):
        """Записать палитру напрямую в .pal через eet (обход бага EFL).

        Это делает то же, что paledit при движении ползунка:
        1. Читает .pal через eet -d
        2. Заменяет значения цветов в текстовом представлении
        3. Записывает новый .pal через eet -e
        4. Создаёт триггер для E
        """
        import re

        pal_path = Path.home() / ".elementary" / "colors" / f"{pal_name}.pal"
        if not pal_path.exists():
            print(f"Ошибка: файл палитры не найден: {pal_path}")
            return False

        # 1. Прочитать текущий .pal
        result = subprocess.run(
            ["eet", "-d", str(pal_path), "palette"],
            capture_output=True, text=True, check=False
        )
        if result.returncode != 0:
            print(f"Ошибка чтения .pal: {result.stderr}")
            return False
        text = result.stdout

        # 2. Для каждого цвета — заменить r,g,b,a
        replaced = 0
        added = 0
        for name, rgba in palette.items():
            r, g, b = rgba[0], rgba[1], rgba[2]
            a = rgba[3] if len(rgba) > 3 else 255

            # ⭐ Определить, с ':' или без — по имени
            # Если name начинается с '/' — конкретный color_class (без ':')
            # Если name начинается с ':' — Elementary палитра (с ':')
            if name.startswith("/"):
                name_pattern = re.escape(name)      # как есть
            else:
                name_pattern = f":{re.escape(name)}"  # добавить ':'

            pattern = (
                rf'(value "name" string: "{name_pattern}";\s*'
                rf'value "r" uchar: )\d+(;\s*'
                rf'value "g" uchar: )\d+(;\s*'
                rf'value "b" uchar: )\d+(;\s*'
                rf'value "a" uchar: )\d+'
            )
            repl = rf'\g<1>{r}\g<2>{g}\g<3>{b}\g<4>{a}'
            text, count = re.subn(pattern, repl, text)
            if count > 0:
                replaced += count
                print(f"  заменён {name} = {r},{g},{b},{a}")
            else:
                # ⭐ Нет такой записи — добавить в конец блока colors
                new_entry = (
                    f'\n        group "Elm_Palette_Color" struct {{\n'
                    f'            value "name" string: "{name_pattern}";\n'
                    f'            value "r" uchar: {r};\n'
                    f'            value "g" uchar: {g};\n'
                    f'            value "b" uchar: {b};\n'
                    f'            value "a" uchar: {a};\n'
                    f'        }}\n'
                )

                # Найти конец блока "colors" — ищем последний "        }" перед "    }"
                # Простой подход: найти последний "        }\n    }" в тексте
                marker = "        }\n    }"
                if marker in text:
                    # Вставить перед последним "        }\n    }"
                    idx = text.rfind(marker)
                    text = text[:idx] + new_entry + "        }" + text[idx + len("        }"):]
                    # ↑ добавить новую запись, оставив закрывающие скобки
                    added += 1
                    print(f"  добавлен {name} = {r},{g},{b},{a}")

        if replaced == 0 and added == 0:
            print("Ошибка: ни один цвет не был заменён")
            return False

        # 3. Записать во временный текстовый файл
        tmp_txt = Path("/tmp/e_pal_new.txt")
        tmp_pal = Path("/tmp/e_pal_new.pal")
        tmp_txt.write_text(text)

        # 4. Создать .pal через eet -e
        result = subprocess.run(
            ["eet", "-e", str(tmp_pal), "palette", str(tmp_txt), "0"],
            capture_output=True, text=True, check=False
        )
        if result.returncode != 0 or not tmp_pal.exists():
            print(f"Ошибка записи .pal: {result.stderr}")
            return False

        # 5. Скопировать поверх оригинала
        try:
            shutil.copy2(tmp_pal, pal_path)
        except Exception as e:
            print(f"Ошибка копирования .pal: {e}")
            return False

        # 6. Создать триггер для E
        trigger = Path.home() / ".cache" / "e_wallpaper_reload"
        trigger.parent.mkdir(parents=True, exist_ok=True)
        trigger.write_text(str(time.time()))

        print(f"Палитра обновлена: {replaced} цветов записано в {pal_path.name}")
        return True

    def update_color_scheme(self, image_path):
        """Полный цикл: определить цвет → вычислить палитру → записать .pal."""
        base = self.get_dominant_color(image_path)
        if base is None:
            print(f"Не удалось определить цвет для {image_path}")
            return
        palette = self.compute_palette(base)
        self.apply_palette_via_eet(palette["elementary"])
        print(f"Основной цвет: RGB{base}")
    def update_from_active_wallpaper(self):
        """Определить активные обои из конфига E и обновить палитру."""
        # Путь к конфигу E
        cfg_path = Path.home() / ".e" / "e" / "config" / "standard" / "e.cfg"
        if not cfg_path.exists():
            print(f"Конфиг E не найден: {cfg_path}")
            return False

        # Читаем через eet
        result = subprocess.run(
            ["eet", "-d", str(cfg_path), "config"],
            capture_output=True, text=True, check=False
        )
        if result.returncode != 0:
            print(f"Ошибка чтения e.cfg: {result.stderr}")
            return False

        text = result.stdout

        # Ищем desktop_default_background
        # Формат: value "desktop_default_background" string: "/path/to/wallpaper.edj";
        import re
        m = re.search(
            r'value "desktop_default_background" string: "([^"]+)"',
            text
        )
        if not m:
            print("desktop_default_background не найден в e.cfg")
            return False

        bg_path = Path(m.group(1))
        print(f"Активные обои: {bg_path}")

        # Если это .edj — ищем исходную картинку
        if bg_path.suffix == ".edj":
            # Ищем исходник .jpg/.png с тем же именем
            stem = bg_path.stem
            for ext in ['.jpg', '.jpeg', '.png', '.bmp', '.webp']:
                # Ищем в папке обоев
                src = self.watch_dir / (stem + ext)
                if src.exists():
                    print(f"Найден исходник: {src}")
                    self.update_color_scheme(src)
                    return True

            # Если исходник не найден — используем сам .edj
            # (PIL не умеет .edj, но можем попробовать)
            print(f"Исходник для {bg_path.name} не найден")
            return False
        else:
            # Это картинка
            if bg_path.exists():
                self.update_color_scheme(bg_path)
                return True
            print(f"Файл не найден: {bg_path}")
            return False

    # ========== END COLOR SCHEME ==========
    
    def convert_to_edj(self, image_path, update_palette=True):
        image_path = Path(image_path)
        
        if image_path.suffix.lower() not in self.supported_formats:
            return False
        
        edj_filename = image_path.stem + '.edj'
        edj_path = self.output_dir / edj_filename
        
        print(f"Конвертация: {image_path.name} -> {edj_filename}")
        
        temp_dir = Path('/tmp/e_wallpaper_convert')
        temp_dir.mkdir(exist_ok=True)
        
        temp_image = temp_dir / image_path.name
        shutil.copy2(image_path, temp_image)
        
        edc_content = f"""images {{
    image: "{image_path.name}" COMP;
}}

collections {{
    group {{
        name: "e/desktop/background";
        
        parts {{
            part {{
                name: "bg";
                type: IMAGE;
                
                description {{
                    state: "default" 0.0;
                    
                    image {{
                        normal: "{image_path.name}";
                        scale_hint: STATIC;
                    }}
                }}
            }}
        }}
    }}
}}
"""
        
        edc_file = temp_dir / 'wallpaper.edc'
        edc_file.write_text(edc_content)
        
        try:
            edje_cc = shutil.which('edje_cc')
            if not edje_cc:
                print("ОШИБКА: edje_cc не найден")
                return False
            
            result = subprocess.run(
                [edje_cc, '-id', str(temp_dir), '-fd', str(temp_dir), 
                 str(edc_file), str(edj_path)],
                check=False,
                capture_output=True,
                text=True,
                cwd=str(temp_dir)
            )
            
            if result.returncode == 0:
                print(f"OK: {edj_path}")
                # Обновить цветовую схему только если нужно
                if update_palette:
                    try:
                        self.update_color_scheme(image_path)
                    except Exception as e:
                        print(f"Ошибка обновления палитры: {e}")
                return True
            else:
                print(f"ОШИБКА: {result.stderr}")
                return False
        
        except Exception as e:
            print(f"Исключение: {e}")
            return False
        
        finally:
            try:
                temp_image.unlink(missing_ok=True)
                edc_file.unlink(missing_ok=True)
            except:
                pass
    
    def remove_edj(self, image_name):
        edj_name = Path(image_name).stem + '.edj'
        edj_path = self.output_dir / edj_name
        
        if edj_path.exists():
            print(f"Удаление: {edj_path.name}")
            edj_path.unlink()
    
    def scan_existing(self):
        print(f"Сканирование {self.watch_dir}...")

        # При сканировании только конвертируем — БЕЗ обновления палитры!
        # Палитра обновится только при СМЕНЕ активных обоев.
        for file in self.watch_dir.iterdir():
            if file.is_file() and file.suffix.lower() in self.supported_formats:
                self.convert_to_edj(file, update_palette=False)

        self.cleanup_orphaned()
    
    def cleanup_orphaned(self):
        source_names = {f.stem for f in self.watch_dir.iterdir() 
                       if f.is_file() and f.suffix.lower() in self.supported_formats}
        
        for edj_file in self.output_dir.glob('*.edj'):
            if edj_file.stem not in source_names:
                print(f"Удаление осиротевшего: {edj_file.name}")
                edj_file.unlink()

def main():

    config_file = Path.home() / '.config' / 'e_wallpaper_daemon.json'
    
    if config_file.exists():
        import json
        config = json.loads(config_file.read_text())
        watch_dir = config.get('watch_dir', sys.argv[1] if len(sys.argv) > 1 else '')
        output_dir = config.get('output_dir', os.path.expanduser('~/.e/e/backgrounds'))
    else:
        if len(sys.argv) < 2:
            print("Укажите папку или настройте через GUI")
            sys.exit(1)
        watch_dir = sys.argv[1]
        output_dir = os.path.expanduser('~/.e/e/backgrounds')
    
    converter = WallpaperConverter(watch_dir, output_dir)
    converter.scan_existing()
    
    # Обновить палитру для текущих активных обоев
    print("Обновление палитры для активных обоев...")
    try:
        converter.update_from_active_wallpaper()
    except Exception as e:
        print(f"Ошибка обновления палитры активных обоев: {e}")
    
    print("Мониторинг активен. Ctrl+C для остановки.")
    
    known_files = {}
    for file in converter.watch_dir.iterdir():
        if file.is_file():
            known_files[file.name] = file.stat().st_mtime
    
    # Отслеживаем изменения e.cfg
    cfg_path = Path.home() / ".e" / "e" / "config" / "standard" / "e.cfg"
    last_cfg_mtime = cfg_path.stat().st_mtime if cfg_path.exists() else 0
    
    try:
        while True:
            time.sleep(0.5)
            
            # Проверить изменение e.cfg (смена активных обоев)
            if cfg_path.exists():
                cur_mtime = cfg_path.stat().st_mtime
                if cur_mtime != last_cfg_mtime:
                    print("Изменение e.cfg — обновление палитры")
                    try:
                        converter.update_from_active_wallpaper()
                    except Exception as e:
                        print(f"Ошибка: {e}")
                    last_cfg_mtime = cur_mtime
            
            current_files = {}
            for file in converter.watch_dir.iterdir():
                if file.is_file():
                    current_files[file.name] = file.stat().st_mtime
            
            for name in current_files:
                if name not in known_files or known_files[name] != current_files[name]:
                    file_path = converter.watch_dir / name
                    if file_path.suffix.lower() in converter.supported_formats:
                        print(f"Обнаружен: {name}")
                        converter.convert_to_edj(file_path)
            
            for name in known_files:
                if name not in current_files:
                    print(f"Исходник удален: {name}")
                    converter.remove_edj(name)
            
            known_files = current_files
    
    except KeyboardInterrupt:
        print("\nОстановлен")

if __name__ == '__main__':
    main()