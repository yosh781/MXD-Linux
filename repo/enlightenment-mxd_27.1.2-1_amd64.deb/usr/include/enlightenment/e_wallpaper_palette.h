#ifdef E_TYPEDEFS
#else
#ifndef E_WALLPAPER_PALETTE_H
#define E_WALLPAPER_PALETTE_H

EINTERN int       e_wallpaper_palette_init(void);
EINTERN int       e_wallpaper_palette_shutdown(void);
EINTERN Eina_Bool e_wallpaper_palette_is_active(void);
EINTERN void      e_wallpaper_palette_reload(void);

#endif
#endif
